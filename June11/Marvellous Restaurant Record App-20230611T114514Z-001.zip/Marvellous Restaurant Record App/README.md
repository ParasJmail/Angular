# RestaurentApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 12.2.10.

## CLone the Repository
```
https://github.com/sibashish99/Restaurent_Application.git

```

## Install node modules
```
npm install

```

## Development server

```
Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.
```

## Json server

```
Run `npx json-server --watch db.json` for a dev server. Navigate to `http://localhost:3000/`. The app will automatically reload if you change any of the source files.
```


